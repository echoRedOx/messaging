# 3Juliet AI Messaging

## Package Id: msg3j

Purpose: Managing message and conversation types for yaml conversion and contextual recall.
